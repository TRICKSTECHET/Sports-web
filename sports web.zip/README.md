# ⚽ Betting Predictions (Web Version)

A simple, modern betting prediction voting website with WhatsApp, Telegram, and AdSense integration.

## 🚀 Run locally
```bash
npm install
npm run dev