import React, { useState } from "react";
import "./style.css";
import appIcon from "./assets/app-icon.png";

export default function App() {
  const [votes, setVotes] = useState({ teamA: 0, teamB: 0 });
  const [voted, setVoted] = useState(false);

  const handleVote = (team) => {
    if (voted) return alert("You’ve already voted!");
    setVotes({ ...votes, [team]: votes[team] + 1 });
    setVoted(true);
  };

  return (
    <div className="app">
      <header>
        <img
          src={appIcon}
          alt="App Logo"
          className="logo"
        />
        <h1>⚽ Betting Predictions</h1>
        <p>Vote for your winning team below!</p>
      </header>

      <div className="vote-container">
        <button onClick={() => handleVote("teamA")}>Team A</button>
        <span className="score">{votes.teamA}</span>
        <button onClick={() => handleVote("teamB")}>Team B</button>
        <span className="score">{votes.teamB}</span>
      </div>

      <div className="ad-section">
        <p>Ad Placeholder (replace with your AdSense block)</p>
        {/* Example AdSense Block:
        <ins class="adsbygoogle"
             style={{display: "block"}}
             data-ad-client="ca-pub-XXXX"
             data-ad-slot="YYYY"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
        */}
      </div>

      <footer>
        <h3>Connect with us</h3>
        <div className="links">
          <a href="https://wa.me/256789186211" target="_blank" rel="noopener noreferrer">
            📱 WhatsApp
          </a>
          <a href="https://t.me/TTH_hk" target="_blank" rel="noopener noreferrer">
            💬 Telegram
          </a>
          <a href="mailto:your@email.com" target="_blank" rel="noopener noreferrer">
            📧 Email
          </a>
        </div>
      </footer>
    </div>
  );
}  